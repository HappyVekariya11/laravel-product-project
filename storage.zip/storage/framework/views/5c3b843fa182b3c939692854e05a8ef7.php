<form action="<?php echo e(route('admin.product-variant.index',$product)); ?>" method="GET">
    <div id="filterBar"
        class="my-4 flex items-center justify-between bg-secondary-100 dark:bg-secondary-900 rounded-lg p-4">

        <div>
            <span class="text-gray-600 dark:text-gray-300"></span>
        </div>


        <div>
            <a href="<?php echo e(route('admin.product-variant.create',$product)); ?>">
                <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.primary-button','data' => ['type' => 'button','class' => 'card-shadow flex items-center']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('primary-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['type' => 'button','class' => 'card-shadow flex items-center']); ?>
                    <i class="fa fa-plus h-5 w-5 me-1.5"></i>
                    Add product-variants
                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
            </a>
        </div>
    </div>
</form>
<?php /**PATH /home/vagrant/code/larafirst/resources/views/admin/variants/partials/search.blade.php ENDPATH**/ ?>