<form action="<?php echo e(route('restaurants.index')); ?>" method="GET">
    <div id="filterBar"
        class="my-4 flex items-center justify-between bg-secondary-100 dark:bg-secondary-900 rounded-lg p-4">
    <a x-on:click="showFilter = !showFilter" href="#" class="flex items-center ms-2">
                <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.secondary-button','data' => ['type' => 'button','class' => 'card-shadow']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('secondary-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['type' => 'button','class' => 'card-shadow']); ?>
                    <i class="fa fa-filter h-5 w-5 me-1.5"></i>
                    Filter
                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
                   <div class="inline-flex ms-auto mt-4">
                    <button class="" type="submit">
                        <i class="fa-solid fa-check h-4 w-4 me-1.5"></i>
                       Apply
                    </button>
                </div>
            </a>
        <div>
            <span class="text-gray-600 dark:text-gray-300"></span>
        </div>
    </div>
      <div x-bind:class="showFilter ? '':'hidden'" class="w-full mt-2.5  z-40 bg-white dark:bg-secondary-700 rounded-lg">

        <div class="flex flex-col lg:flex-row justify-between items-center p-4">

            <ul class="flex flex-wrap w-full">

                <li x-on:click="toggleFilter('latitude')">
                    <a href="#" class="hover:bg-secondary-100 rounded-[5rem] border-0 text-[#848B98] dark:text-secondary-400 dark:hover:bg-secondary-600 font-medium px-3.5 py-1.5">latitude
                        <span x-bind:class="filter == 'latitude' ? 'hidden' : '' "><i class="fa-solid fa-chevron-down font-bold ms-0.5"></i></span>
                        <span x-bind:class="filter != 'latitude' ? 'hidden' : '' "><i class="fa-solid fa-chevron-up font-bold ms-0.5"></i></span>
                    </a>
                </li>
                <li x-on:click="toggleFilter('longitude')">
                    <a href="#" class="hover:bg-secondary-100 rounded-[5rem] border-0 text-[#848B98] dark:text-secondary-400 dark:hover:bg-secondary-600 font-medium px-3.5 py-1.5">longitude
                        <span x-bind:class="filter == 'longitude' ? 'hidden' : '' "><i class="fa-solid fa-chevron-down font-bold ms-0.5"></i></span>
                        <span x-bind:class="filter != 'longitude' ? 'hidden' : '' "><i class="fa-solid fa-chevron-up font-bold ms-0.5"></i></span>
                    </a>
                </li>
            </ul>
        

        </div>

        <div class="px-4 pb-4" x-show="filter" x-cloak>

            <div x-show="filter == 'latitude'" class="flex justify-between items-center w-full">
                <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.app-input','data' => ['label' => 'latitude','value' => request()->input('latitude'),'name' => 'latitude','id' => 'latitude','class' => 'block w-full','type' => 'text']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'latitude','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(request()->input('latitude')),'name' => 'latitude','id' => 'latitude','class' => 'block w-full','type' => 'text']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
            </div>
            <div x-show="filter == 'longitude'">
                <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.app-input','data' => ['label' => 'longitude','value' => request()->input('longitude'),'name' => 'longitude','id' => 'longitude','class' => 'block w-full','type' => 'text']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'longitude','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(request()->input('longitude')),'name' => 'longitude','id' => 'longitude','class' => 'block w-full','type' => 'text']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
                
            </div>
        
        </div>

    </div>
</form>
<?php /**PATH /home/vagrant/code/larafirst/resources/views/restaurants/partials/search.blade.php ENDPATH**/ ?>