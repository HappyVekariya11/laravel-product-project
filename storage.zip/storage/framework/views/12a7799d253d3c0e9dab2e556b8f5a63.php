<?php echo e($slot); ?>

<?php /**PATH /home/vagrant/code/larafirst/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/panel.blade.php ENDPATH**/ ?>