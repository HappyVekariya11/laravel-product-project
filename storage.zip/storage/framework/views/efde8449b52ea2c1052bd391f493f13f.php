<div class="mt-6">
<?php echo e($slot); ?>

</div><?php /**PATH /home/vagrant/code/larafirst/resources/views/components/form/field.blade.php ENDPATH**/ ?>