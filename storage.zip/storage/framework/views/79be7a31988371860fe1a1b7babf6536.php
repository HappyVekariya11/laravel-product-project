<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="/app1.css">

</head>
<body>
    <article>

    <?= $post;?>
     <!-- <h1><a href="/post">paragraph</a></h1>     
    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Nisi reiciendis
            perspiciatis ipsa illum ipsum animi, nemo consequuntur temporibus quod
            ex facilis facere nesciunt dolore excepturi qui iste! Magnam in sint
            quaerat nihil dolorum. Consequuntur est animi eveniet fugiat vel
            reiciendis magni blanditiis optio laudantium tempora ipsum quibusdam
            ducimus atque adipisci aut numquam ea, sed inventore porro! Dicta minus
            provident quos tempore eum dolore soluta officiis. Aliquam voluptatem
            suscipit modi earum sequi iusto nulla quo asperiores eaque natus!
            Soluta voluptate asperiores rerum nihil porro magni, inventore aut
            consequatur neque quia deserunt iste placeat, similique quam fuga
            distinctio. Est, laboriosam libero? Optio vero quasi voluptatibus? Doloribus exercitationem doloremque ab et voluptas vitae explicabo impedit enim animi. Error ab consectetur, hic similique odit nostrum quae est?</p>-->
    </article>
    <a href="/">go home page </a>  
</body>
</html><?php /**PATH /home/vagrant/code/larafirst/resources/views/post.blade.php ENDPATH**/ ?>