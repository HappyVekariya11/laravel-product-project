<div <?php echo e($attributes(["border border-gray-200 p-6 rounded-xl"])); ?>>
<?php echo e($slot); ?>

</div><?php /**PATH /home/vagrant/code/larafirst/resources/views/components/panel.blade.php ENDPATH**/ ?>