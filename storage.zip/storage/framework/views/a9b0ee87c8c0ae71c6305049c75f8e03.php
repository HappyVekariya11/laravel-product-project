
<?php $__env->startComponent('mail::message'); ?>
Hello <?php echo e(auth()->user()->name); ?>,

Your <?php echo e($post->title); ?> post has been successfully created.

Thanks,<br>
<?php echo e(config('app.name')); ?>

<?php echo $__env->renderComponent(); ?><?php /**PATH /home/vagrant/code/larafirst/resources/views/mail/new-post.blade.php ENDPATH**/ ?>