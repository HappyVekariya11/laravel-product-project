<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="/app1.css">
</head>
<header>
<?php echo $__env->yieldContent('banner'); ?>
</header>
<body>
   <?php echo $__env->yieldContent('content'); ?>
</body>

</html>
<?php /**PATH /home/vagrant/code/larafirst/resources/views/layout.blade.php ENDPATH**/ ?>