<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Your Website</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        nav {
            background-color: #333;
            overflow: hidden;
        }

        nav a {
            float: left;
            display: block;
            color: white;
            text-align: center;
            padding: 14px 16px;
            text-decoration: none;
        }

        nav a:hover {
            background-color: #ddd;
            color: black;
        }

        .category-section {
            padding: 20px;
        }

        .category {
            display: inline-block;
            margin: 10px;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 5px;
        }
    </style>
</head>
<body>

<!-- Navigation Bar -->
<nav>
    <a href="#home">Home</a>
    <a href="#categories">Categories</a>
    <a href="#about">About Us</a>
    <a href="#contact">Contact</a>
</nav>

<!-- Category Section -->
<div class="category-section">
    <div class="category">
        <h2>Category 1</h2>
        <p>Description of Category 1.</p>
    </div>
    <div class="category">
        <h2>Category 2</h2>
        <p>Description of Category 2.</p>
    </div>
    <div class="category">
        <h2>Category 3</h2>
        <p>Description of Category 3.</p>
    </div>
</div>

<!-- Content of your website goes here -->

</body>
</html>
<?php /**PATH /home/vagrant/code/larafirst/resources/views/happy.blade.php ENDPATH**/ ?>