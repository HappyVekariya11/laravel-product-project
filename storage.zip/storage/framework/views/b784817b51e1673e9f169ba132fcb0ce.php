
<div class="bg-secondary-100 dark:bg-secondary-900 rounded-lg p-6 mt-2.5">

    <div class="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-4 gap-6">

        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <a href="<?php echo e(route('products.variants', $product->id)); ?>"
               class="block bg-white dark:bg-secondary-800 rounded-xl shadow-md hover:shadow-xl hover:-translate-y-1 transition duration-300 p-6 text-center">

                <h3 class="text-lg font-semibold dark:text-secondary-200 truncate">
                    <?php echo e($product->name); ?>

                </h3>

                <p class="text-sm text-gray-500 dark:text-secondary-400 mt-1">
                    View Variants
                </p>

            </a>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </div>

</div><?php /**PATH /home/vagrant/code/larafirst/resources/views/admin/products/partials/product.blade.php ENDPATH**/ ?>