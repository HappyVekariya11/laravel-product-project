
<div class="bg-secondary-100 dark:bg-secondary-900 rounded-lg p-6 mt-2.5">

    <div class="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-4 gap-4">

        <?php $__currentLoopData = $variants; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $variant): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <div class="bg-white dark:bg-secondary-800 rounded-lg shadow hover:shadow-lg transition duration-300 overflow-hidden">

                <div class="aspect-square bg-gray-100 overflow-hidden flex items-center justify-center">

                    <?php if($variant->images->count() > 0): ?>

                        <img src="<?php echo e(asset($variant->images->first()->image)); ?>"
                             class="w-full h-full object-cover hover:scale-105 transition duration-300">

                    <?php else: ?>
                        <span class="text-gray-400 text-sm">
                            No Image Found
                        </span>
                    <?php endif; ?>

                </div>

           
                <div class="p-4">

                    <h3 class="text-lg font-semibold dark:text-secondary-200 truncate">
                        <?php echo e($variant->name); ?>

                    </h3>

                    <p class="text-sm text-gray-500 dark:text-secondary-400 mt-1 line-clamp-2">
                        <?php echo e($variant->description); ?>

                    </p>

                    <?php $__currentLoopData = $variant->prices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $price): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <p class="text-sm text-gray-600 dark:text-secondary-300 mt-2">
                            Price: $<?php echo e($price->price); ?>

                        </p>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </div>

            </div>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </div>

</div>
<?php /**PATH /home/vagrant/code/larafirst/resources/views/admin/variants/partials/card.blade.php ENDPATH**/ ?>