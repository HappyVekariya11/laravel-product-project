<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag; ?>
<?php foreach($attributes->onlyProps(['disabled' => false, 'src' => 'https://placehold.co/200']) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps(['disabled' => false, 'src' => 'https://placehold.co/200']); ?>
<?php foreach (array_filter((['disabled' => false, 'src' => 'https://placehold.co/200']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>
<?php
$attributes->merge(['id' => '', 'label' => '', 'name' => '']);

$attributes->merge(['class' => $errors->has($attributes['name']) ? 'has-error' : '']);
$path = $src == 'https://placehold.co/200' ? null : 'public/' . preg_replace('#^.*?public/(.*?)(\?.*|$)#', '$1', $src);
?>
<div class="h-full">
    <div x-data="imageInput"
        class="relative border border-secondary-400 hover:border hover:border-secondary-700 bg-transparent rounded-lg border-1  dark:hover:border-secondary-200 appearance-none  dark:border-secondary-600 dark:focus:border-primary-500 focus:outline-none focus:ring-0 focus:border-primary-600">


        <?php if(!empty($path)): ?>
        <input type="hidden" x-ref="filePathInput" name="<?php echo e($attributes['name']); ?>_path" value="<?php echo e($path); ?>" />
        <?php endif; ?>

        <div class="relative flex items-center justify-between  w-full p-3">
            <img @click="changeFile" x-ref="displayImage" src="<?php echo e($src); ?>"
                class="rounded-2xl h-24 w-24 peer dark:bg-dark-600 " />

            <div class="editor absolute top-0 right-0 hidden">
                <input x-ref="fileInput" type="file" @change="previewImage" <?php echo e($disabled ? 'disabled' : ''); ?>

                    <?php echo $attributes->merge([
                'placeholder' => ' ',
                'class' => 'h-8 w-8',
                ]); ?> />
            </div>

            <div class="flex items-center">

                <div x-cloak>
                    <a class="primary-ward-font me-2" @click="openWebCam(false)">
                        <span class="w-duto h-auto text-gray-500 hover:text-gray-800 hover:dark:text-secondary-300">
                            <i class="fa-solid fa-camera h-5 w-5"></i>
                        </span>
                    </a>
                    <div x-show="isPopupOpen"
                        class="fixed inset-0 bg-gray-800 bg-opacity-50 z-40 flex items-center justify-center"
                        x-transition.opacity x-on:click.self="closeWebCam">
                    </div>
                    <div x-show="isPopupOpen" x-transition
                        class="fixed top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 bg-white dark:bg-dark-200 rounded-lg shadow-lg z-50 p-1 w-80 max-w-full">

                        <a href="javascript:void(0)"
                            class="absolute text-white bg-secondary-700 dark:bg-white dark:text-secondary-800 dark:hover:bg-danger-500 hover:bg-danger-500 dark:hover:text-white hover:text-white p-1.5 -right-[18px] -top-[18px] rounded-full font-bolder cursor-pointer flex justify-center items-center"
                            @click="closeWebCam">
                            <i class="fa-solid fa-xmark h-6 w-6"></i>
                        </a>

                        <!-- Webcam Feed -->
                        <div x-show="step=='video'" class="relative flex flex-col items-center w-full h-full">
                            <video x-ref="player" class="mb-2" autoplay></video>

                            <!-- Click Button Centered -->
                            <a href="javascript:void(0)" x-on:click="preview"
                                class="absolute bottom-4 left-1/2 transform -translate-x-1/2">
                                <i class="fap-solid fap-camera-viewfinder text-4xl text-secondary-400"></i>
                            </a>

                            <!-- Rotate Icon on the Right -->
                            <a href="javascript:void(0)" x-on:click="toggleWebCam()"
                                class="absolute bottom-4 right-4">
                                <i class="fap-light fap-camera-rotate text-2xl text-secondary-400"></i>
                            </a>
                        </div>

                        <div x-show="step=='preview'" class="flex flex-col items-center">
                            <canvas style="width:290px;height:240px;" x-ref="snapshot" class="mt-4 border rounded"
                                width="1280" height="960"></canvas>
                            <div class="flex gap-2 mt-2">
                                <a href="javascript:void(0)" x-on:click="step='video'"
                                    class="px-4 py-2 bg-gray-500 text-white rounded"><?php echo e(__('common/terms.retake')); ?></a>
                                <a href="javascript:void(0)" x-on:click="load"
                                    class="px-4 py-2 bg-blue-500 text-white rounded ">
                                    <?php echo e(__('common/terms.submit')); ?></a>


                            </div>
                        </div>
                    </div>
                </div>

                <a class="primary-ward-font" @click="changeFile">
                    <span class="w-duto h-auto text-primary-400 hover:text-primary-600 me-2">
                        <i class="fa-regular fa-image h-5 w-5"></i>
                    </span>
                </a>

                <a @click="deleteFile" x-show="hasFile">
                    <span class="w-duto h-auto text-danger-400 hover:text-danger-600 me-2">
                        <i class="fa-solid fa-trash-can h-5 w-5"></i>
                    </span>
                </a>
            </div>

        </div>

        <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input-label','data' => ['for' => ''.e($attributes['id']).'','value' => __($attributes['label'])]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('input-label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['for' => ''.e($attributes['id']).'','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(__($attributes['label']))]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>

    </div>

    <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input-error','data' => ['messages' => $errors->get($attributes['name']),'class' => 'mt-2']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('input-error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['messages' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($errors->get($attributes['name'])),'class' => 'mt-2']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>

</div><?php /**PATH /home/vagrant/code/larafirst/resources/views/components/image-input.blade.php ENDPATH**/ ?>