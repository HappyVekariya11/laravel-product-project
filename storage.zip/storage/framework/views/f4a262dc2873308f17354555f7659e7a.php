<button type="submit" class="bg-blue-500 text-white uppercase font-semibold text-xs py-2 px-10 rounded-2xl hover:bg-blue-600">

    <?php echo e($slot); ?>

</button><?php /**PATH /home/vagrant/code/larafirst/resources/views/components/submit-button.blade.php ENDPATH**/ ?>