<div class="grid grid-cols-12 md:gap-5 gap-3 h-full mb-5 items-center p-6 bg-white dark:bg-secondary-700 rounded-lg w-full">

    <div class="relative lg:col-span-6 md:col-span-6 col-span-12 w-full">
        <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.app-input','data' => ['label' => 'name','id' => 'name','type' => 'text','placeholder' => '','name' => 'name','value' => $category->name ?? old('name'),'autocomplete' => true,'required' => 'name']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'name','id' => 'name','type' => 'text','placeholder' => '','name' => 'name','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($category->name ?? old('name')),'autocomplete' => true,'required' => 'name']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
    </div>
      
   
</div>
<?php /**PATH /home/vagrant/code/larafirst/resources/views/categories/partials/form.blade.php ENDPATH**/ ?>